# CART3R Discord bot

This is starter code for a simple Discord bot.

## Files
- `bot.py` — the bot
- `requirements.txt` — Python dependency

## Important setup
1. In the Discord Developer Portal, open your CART3R application.
2. Open **Bot** and enable **Message Content Intent** under Privileged Gateway Intents.
3. Keep your bot token secret. Never paste it into `bot.py`, GitHub files, screenshots, or public chats.
4. When hosting the bot, add an environment variable named `DISCORD_TOKEN` and put your bot token in that host's secret/environment-variable settings.
5. Install dependencies with `pip install -r requirements.txt`.
6. Start it with `python bot.py`.

## Commands
- `!hello`
- `!ping`
- Mention CART3R in a channel to get a greeting.

GitHub Pages only hosts the website; it does not keep a Python Discord bot running. The bot needs a separate Python-capable hosting service.
