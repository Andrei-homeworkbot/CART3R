import os
import discord
from discord.ext import commands

# Add your Discord bot token as an environment variable named DISCORD_TOKEN.
TOKEN = os.getenv("DISCORD_TOKEN")

if not TOKEN:
    raise RuntimeError("Missing DISCORD_TOKEN environment variable.")

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    print(f"CART3R is online as {bot.user}")

@bot.command()
async def hello(ctx):
    await ctx.send("Hey! CART3R is here. 🤖")

@bot.command()
async def ping(ctx):
    await ctx.send("I'm online! 🟢")

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    # Reply when someone mentions CART3R.
    if bot.user and bot.user in message.mentions:
        await message.channel.send(
            f"Hey {message.author.mention}! I'm CART3R. Try `!hello` or `!ping`."
        )

    await bot.process_commands(message)

bot.run(TOKEN)
