import os
import time
import threading
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests
from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024
_lock = threading.Lock()
_state = {
    "status": "Idle",
    "platform": None,
    "started_at": None,
    "finished_at": None,
    "results": [],
    "message": "Choose a platform to run a public-page performance check."
}

# Configure official, approved test URLs in Enzonic environment variables.
# These defaults are public landing pages and are only checked for reachability.
PLATFORMS = {
    "reader": {
        "name": "Sparx Reader",
        "url": os.getenv("SPARX_READER_URL", "https://www.sparxreader.com/")
    },
    "maths": {
        "name": "Sparx Maths",
        "url": os.getenv("SPARX_MATHS_URL", "https://www.sparxmaths.com/")
    },
    "science": {
        "name": "Sparx Science",
        "url": os.getenv("SPARX_SCIENCE_URL", "https://www.sparxscience.com/")
    },
}

def check_page(platform_key):
    platform = PLATFORMS[platform_key]
    url = platform["url"]
    started = time.perf_counter()
    result = {
        "platform": platform["name"],
        "url": url,
        "status": "Failed",
        "http_status": None,
        "response_ms": None,
        "error": None,
        "checked_at": datetime.now(timezone.utc).isoformat()
    }
    try:
        parsed = urlparse(url)
        if parsed.scheme != "https" or not parsed.netloc:
            raise ValueError("Test URL must be a valid HTTPS URL.")
        response = requests.get(
            url,
            timeout=15,
            headers={"User-Agent": "CART3R-QA-Monitor/1.0"},
            allow_redirects=True
        )
        result["http_status"] = response.status_code
        result["response_ms"] = round((time.perf_counter() - started) * 1000)
        result["status"] = "Passed" if response.ok else "Warning"
        if not response.ok:
            result["error"] = f"Server returned HTTP {response.status_code}"
    except requests.Timeout:
        result["response_ms"] = round((time.perf_counter() - started) * 1000)
        result["error"] = "Request timed out after 15 seconds."
    except Exception as exc:
        result["response_ms"] = round((time.perf_counter() - started) * 1000)
        result["error"] = str(exc)[:240]
    return result

def run_test(platform_key):
    with _lock:
        _state.update({
            "status": "Running",
            "platform": PLATFORMS[platform_key]["name"],
            "started_at": datetime.now(timezone.utc).isoformat(),
            "finished_at": None,
            "results": [],
            "message": "Checking the platform's public page. No homework is opened or submitted."
        })
    result = check_page(platform_key)
    with _lock:
        _state["results"] = [result]
        _state["status"] = "Complete" if result["status"] == "Passed" else "Needs attention"
        _state["finished_at"] = datetime.now(timezone.utc).isoformat()
        _state["message"] = (
            "Public-page check completed. This does not verify account login or homework."
        )

@app.get("/")
def index():
    return render_template("index.html")

@app.get("/api/status")
def status():
    with _lock:
        return jsonify(dict(_state))

@app.post("/api/test")
def start_test():
    data = request.get_json(silent=True) or {}
    key = data.get("platform")
    if key not in PLATFORMS:
        return jsonify({"error": "Choose Reader, Maths or Science."}), 400
    with _lock:
        if _state["status"] == "Running":
            return jsonify({"error": "A test is already running."}), 409
    thread = threading.Thread(target=run_test, args=(key,), daemon=True)
    thread.start()
    return jsonify({"ok": True, "message": "Test started."}), 202

@app.post("/api/connect")
def connect_account():
    # Deliberately do not save, log, or forward account credentials.
    # Actual login testing requires an approved test tenant and a reviewed adapter.
    data = request.get_json(silent=True) or {}
    platform = data.get("platform")
    email = str(data.get("email", "")).strip()
    username = str(data.get("username", "")).strip()
    password = str(data.get("password", ""))
    if platform not in PLATFORMS:
        return jsonify({"error": "Choose a platform."}), 400
    if not email or not username or not password:
        return jsonify({"error": "Enter email, username and password."}), 400
    # Clear local references immediately; never persist or print the password.
    del password
    del username
    del email
    return jsonify({
        "ok": True,
        "message": (
            "The form was received securely for this request, but CART3R has not "
            "attempted a login. Credentials were not saved. Login testing can only "
            "be enabled after the authorised Sparx test environment and login flow "
            "are confirmed."
        )
    })

@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "CART3R dashboard"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8080")))
