import os
import threading
import discord
from discord import app_commands
from app import app

TOKEN = os.getenv("DISCORD_TOKEN")

class CART3R(discord.Client):
    def __init__(self):
        intents = discord.Intents.default()
        super().__init__(intents=intents)
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        await self.tree.sync()

    async def on_ready(self):
        print(f"CART3R is online as {self.user}")
        await self.change_presence(
            activity=discord.Game("Monitoring authorised QA checks")
        )

bot = CART3R()

@bot.tree.command(name="ping", description="Check whether CART3R is online")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(
        f"🤖 CART3R is online! Latency: {round(bot.latency * 1000)}ms",
        ephemeral=True
    )

@bot.tree.command(name="help", description="Show CART3R commands")
async def help_command(interaction: discord.Interaction):
    embed = discord.Embed(
        title="CART3R Help Centre",
        description="Use the web dashboard to run authorised Sparx page checks.",
        color=discord.Color.blurple()
    )
    embed.add_field(name="/ping", value="Check bot status.", inline=False)
    embed.add_field(
        name="Dashboard",
        value="Open your Enzonic web service to select Reader, Maths or Science.",
        inline=False
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)

def run_bot():
    if TOKEN:
        bot.run(TOKEN)
    else:
        print("DISCORD_TOKEN not set; dashboard will run without Discord.")

if __name__ == "__main__":
    threading.Thread(
        target=lambda: app.run(
            host="0.0.0.0",
            port=int(os.getenv("PORT", "8080")),
            use_reloader=False
        ),
        daemon=True
    ).start()
    run_bot()
