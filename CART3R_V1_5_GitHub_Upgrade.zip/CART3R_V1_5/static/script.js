const $ = (id) => document.getElementById(id);

async function runTest(platform) {
  $("statusPill").textContent = "RUNNING";
  $("statusPill").className = "status-pill running";
  $("testTitle").textContent = "Running " + platformLabel(platform) + " check…";
  $("testMessage").textContent = "Checking public-page availability and response time.";
  $("httpStatus").textContent = "…";
  $("responseTime").textContent = "…";
  $("resultError").textContent = "";
  try {
    const response = await fetch("/api/test", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({platform})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not start test.");
    pollStatus();
  } catch (error) {
    $("testMessage").textContent = error.message;
    $("statusPill").textContent = "ERROR";
    $("statusPill").className = "status-pill";
  }
}
function platformLabel(key) {
  return ({reader:"Sparx Reader", maths:"Sparx Maths", science:"Sparx Science"})[key] || key;
}
async function refreshStatus() { await pollStatus(); }
async function pollStatus() {
  try {
    const response = await fetch("/api/status");
    const data = await response.json();
    const running = data.status === "Running";
    $("statusPill").textContent = data.status.toUpperCase();
    $("statusPill").className = "status-pill " + (running ? "running" : (data.results.length ? "done" : ""));
    $("testTitle").textContent = data.platform ? data.platform + " — " + data.status : "No test run yet";
    $("testMessage").textContent = data.message;
    if (data.results && data.results.length) {
      const result = data.results[0];
      $("httpStatus").textContent = result.http_status ?? "—";
      $("responseTime").textContent = result.response_ms == null ? "—" : result.response_ms + " ms";
      $("resultError").textContent = result.error || "";
    }
    if (running) setTimeout(pollStatus, 1200);
  } catch (_) {}
}
$("accountForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  const payload = {
    platform: $("platform").value,
    email: $("email").value,
    username: $("username").value,
    password: $("password").value
  };
  try {
    const response = await fetch("/api/connect", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    const data = await response.json();
    $("accountMessage").hidden = false;
    $("accountMessage").textContent = data.message || data.error;
    $("accountMessage").style.borderColor = response.ok ? "#3b725b" : "#754848";
  } catch (_) {
    $("accountMessage").hidden = false;
    $("accountMessage").textContent = "Could not contact CART3R. Please try again.";
  } finally {
    $("password").value = "";
    button.disabled = false;
  }
});
pollStatus();
