# CART3R V1.5

A Flask dashboard plus Discord bot for authorised QA monitoring.

## Included
- Dark responsive dashboard with Reader / Maths / Science selectors
- Public-page HTTPS availability and response-time checks
- Discord `/ping` and `/help`
- Account form UI for test-account workflow
- Credentials are not stored, logged, or forwarded

## Important scope
This starter performs public-page checks only. It does not sign into Sparx, open or complete compulsory homework, submit answers, or bypass site controls. Do not enter real passwords into an untrusted deployment. The account form currently validates the fields, immediately clears the password in the browser, and explains that no login was attempted. A real login QA adapter should only be added for a test tenant with explicit written authorisation and documented test selectors.

## Local run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python bot.py
```
Open http://localhost:8080.

Set `DISCORD_TOKEN` as an environment variable to enable the Discord bot. Never commit tokens.

## Enzonic
- Build/install command: `pip install -r requirements.txt`
- Start command: `python bot.py`
- Add `DISCORD_TOKEN` as a private environment variable.
- Set `PORT` if your host requires a specific port.
- Optional URL overrides: `SPARX_READER_URL`, `SPARX_MATHS_URL`, `SPARX_SCIENCE_URL`.

The host must support a persistent Python web process and outbound HTTPS requests.
